const {ccclass, property} = cc._decorator;

@ccclass
export default class Helloworld extends cc.Component {

    @property({
        type: cc.Node,
    })
    maskNode = null;

    onLoad() {

        // // 开启物理世界
        // const collMgr = cc.director.getCollisionManager();
        // collMgr.enabled = true;
        // collMgr.enabledDebugDraw = true;
        // collMgr.enabledDrawBoundingBox = true;
        // cc.director.getPhysicsManager().enabled = true;


    }

    start () {

    }

    onDestroy() {

    }

    private _createLiu(): void {
        const g = new b2Vec2(0, -10); // 重力
        // const
    }
}
